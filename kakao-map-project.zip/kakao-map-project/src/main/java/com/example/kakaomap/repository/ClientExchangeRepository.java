package com.example.kakaomap.repository;

import com.example.kakaomap.entity.ClientExchangeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientExchangeRepository extends JpaRepository<ClientExchangeEntity, Long> {
}
