package com.example.kakaomap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KakaoMapApplication {

    public static void main(String[] args) {
        SpringApplication.run(KakaoMapApplication.class, args);
    }

}
