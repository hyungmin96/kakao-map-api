package com.example.kakaomap.repository;

import com.example.kakaomap.entity.ExchangeFileEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientExchangeFileRepository extends JpaRepository<ExchangeFileEntity, Long> {
}
