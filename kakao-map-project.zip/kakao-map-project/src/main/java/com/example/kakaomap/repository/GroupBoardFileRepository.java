package com.example.kakaomap.repository;

import com.example.kakaomap.entity.GroupBoardFileEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GroupBoardFileRepository extends JpaRepository<GroupBoardFileEntity, Long> {
}
